package com.cts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entity.SurveyReport;

public interface SurveyReportRepository extends JpaRepository<SurveyReport, String>{

}
